const name = 'john doe'
export{name}