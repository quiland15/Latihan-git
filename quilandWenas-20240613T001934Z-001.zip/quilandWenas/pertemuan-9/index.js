//rest parameter & spread operator

let arrayB = [1, 2, 3, 4, 5]

console.log(`ini adalah spread operator ${[...arrayB]}`)