//Javascript ES6

//penggunaan let & const pada array dan object

const number = [1, 2, 3, 4, 5];

number[2] = 10;


console.log(number)


