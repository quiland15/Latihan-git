//JavaScript Variable

//let first_name = "Jhon"; //Snake Case
//let FirstName = "Jhon"; //Pascal Case
//let firstName = "Jhon"; //Camel Case

//Tipe Data

//let firstName = "Jhon"; //String
//let age = 30; //Number
//let isMarried = true; //Boolean

//console.log(firstName, age, isMarried);
//let address;
//console.log(address); //undefined
//address = "Airmadidi";
//console.log(address);


//JavaScrip operator
//Arimatik
//let bil1 = 10;
//let bil2 = 3;

//console.log(bil1 + bil2);
//console.log(bil1 - bil2);
//console.log(bil1 / bil2);
//console.log(bil1 * bil2);
//console.log(bil1 ** bil2);
//console.log(bil1 % bil2);
//console.log(bil1 ++);//Wajib di luar console.log
//console.log(bil1 --);//Wajib di luar console.log

//Assignment

//let x = 10;

//x += 2;
//console.log(x);

//String Operators

//let firstName = "jhon";
//let lastName = "Doe";

//console.log(firstName + " " + lastName);

//Equality Operator

//let x = 10;
//let y = "10";

//console.log(x == y);//True
//console.log(x === y);//False

//JavaScript Function

function greetings(name){
	let String = "Hello " + name;
	return String;
}

let output = greetings("Quiland");

console.log(output);

const greetings2 = function(){
	console.log("Hello World");
};

greetings2();

